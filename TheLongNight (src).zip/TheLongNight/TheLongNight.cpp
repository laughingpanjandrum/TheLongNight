#include "libtcod.hpp"
#include "game.h"

int main() {
	game g;
	g.mainGameLoop();
}